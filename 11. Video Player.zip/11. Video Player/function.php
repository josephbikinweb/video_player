<?php  
    $conn = mysqli_connect("localhost","root","","video_player");

     function query($query) {
        global $conn;
        $result = mysqli_query($conn, $query);
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
            // $rows sebagai array baru yang isinya row + row + row
        }
        return $rows;
    }
    
    function tambah($data) {
        global $conn;
    // ambil data dari tiap elemen dalam form 
    // supaya tidak mudah disusupi script dari orang luar alias dihack maka ditambahkan code : htmlspecialchars()
        $judul = htmlspecialchars($data ["judul"]);
        
    // UPLOAD gambar
            $video = upload();
            if ( !$video) {
                return false;
            }

        $query = "INSERT INTO video 
                VALUES
        -- urutannya (id -meskipun nilai kosong krn autoincrement- JANGAN SAMPAI SALAH URUTAN )
                ('', '$judul', '$video')
            ";
    // query insert data (koneksi, query) ; untuk menampilkan pakai SELECT * FROM
        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }

    // FUNCTION upload :
    function upload() {
        
        $judulFile = $_FILES['video']['name'];
        $ukuranFile = $_FILES['video']['size'];
        $error = $_FILES ['video']['error'];
        $tmpName = $_FILES ['video']['tmp_name'];
    
    // Apakah tidak ada gambar yang diupload
        if ( $error === 4) {
            echo"<script>
                        alert('pilih file video terlebih dahulu');
                    </script>";
                return false;
        }
    // cek apakah yang diupload adalah gambar
        $ekstensiVideoValid = ['mp4'];
            // explode :sebuah fungsi untuk memecah string menjadi array
            // contoh : img1.png menjadi = ['img1', 'png'] 
        $ekstensiVideo = explode('.',$judulFile);
            // untuk memastikan yang diambil adalah ekstensi yang terakhir maka gunakan end
            // untuk memastikan semua memakai huruf kecil maka gunakan strtolower
        $ekstensiVideo = strtolower(end($ekstensiVideo));

        if( !in_array($ekstensiVideo, $ekstensiVideoValid)) {
            echo"<script>
                        alert('yang anda upload bukan Video');
                    </script>";
                return false;
        }
    // cek jika ukurannya terlalu besar
        if( $ukuranFile > 1000000000) {
            echo"<script>
                        alert('ukuran gambar terlalu besar');
                    </script>";
                return false;
        }

        // lolos pengecekan, gambar siap diupload
        
        move_uploaded_file($tmpName, 'video/' . $judulFile);
        // kenapa kok namaFileBaru direturn? supaya $gambar diidentifikasi sbg gambar
        return $judulFile;
        
    }

    // HAPUS

     function hapus ($id) {
        global $conn;
        mysqli_query ($conn,"DELETE FROM video WHERE id = $id");
        
         return mysqli_affected_rows($conn);
    }

    // UBAH
     
    function ubah ($data) {
        global $conn;
    // ambil data dari tiap elemen dalam form 
    // supaya tidak mudah disusupi script dari orang luar alias dihack maka ditambahkan code : htmlspecialchars()
        $id = $data["id"];
        $judul= htmlspecialchars($data ["judul"]);
        $videoLama = htmlspecialchars($data ["videoLama"]);

    // cek apakah user pilih gambar baru atau tidak
        if ( $_FILES['video']['error'] === 4) {
            $video = $videoLama;
        } else {
            $gambar = upload();
        }

        $query = "UPDATE video SET
                judul = '$judul',
                video = '$video'
            WHERE id = $id
            ";
    // query insert data (koneksi, query) ; untuk menampilkan pakai SELECT * FROM
        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }

    // function cari
    function cari($keyword) {
        $query = "SELECT * FROM video
                    WHERE
                    judul LIKE '%$keyword%'                      
                ";
        return query($query);
    }
    
?>