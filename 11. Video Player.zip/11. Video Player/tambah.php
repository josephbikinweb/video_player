<?php  
require "function.php";
// BELAJAR PHP untuk pemula 12.Insert dan Delete
// beda dengan tambah copy adalah ambil data dipindahkan ke function
// koneksi ke DBMS
$video = query("SELECT * FROM video ORDER BY video");
 
// cek apakah tombol submit sudah ditekan atau belum
    if (isset ($_POST["submit"])) {

// untuk fungsi debug / cek codingannya bekerja atau tidak :
// die supaya coding dibawahnya tidak dijalankan
        // var_dump($_POST); 
        // var_dump($_FILES); die;

// cek apakah data berhasil ditambahkan atau tidak
        if (tambah($_POST) > 0){
            // echo "Data berhasil ditambahkan";
            echo "
                <script>
                    alert ('data berhasil ditambahkan');
                    document.location.href = 'index.php';
                </script>
            ";
        } else {
            // echo"Data GAGAL ditambahkan";
            // echo "<script>
            //         alert ('data gagal ditambahkan');
            //         document.location.href = 'index.php';
            //     </script>
            //     ";
            var_dump ($_POST);
            die;
        }
    }
    
    if (isset($_POST["cari"])) {
    $video = cari($_POST["keyword"]);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <form action="" method="post" enctype="multipart/form-data">
            <h1 class="mt-3">Tambah Video</h1>
                <div class="form-group">
                    <label for="judul">Judul :</label>
                    <input type="text" name="judul" id="judul" class="form-control">
                </div>
                <div class="form-group">
                    <label for="video">Video :</label>
                    <input type="file" name="video" id="video" class="form-control">
                </div>
                    <button type="submit" name="submit" class="btn btn-primary">Tambah Video</button>
               </form>
        </div>
    </div>

    <div class="container my-5">
      <div class="row">
        <form action="" method="post">
          <div class="form-inline">
            <input type="text" name="keyword" size="40" autofocus placeholder="masukkan keyword pencarian.." autocomplete="off"  class="form-control" id="keyword">
            <button type="submit" name="cari" class="btn btn-primary ml-2" id="tombol-cari">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="container" id="container">
      <div class="row">
        <table class="table mt-5">
          <thead class="thead-dark">
            <tr>
              <th scope="col">No.</th>
              <!--Aksi untuk tombol ubah  -->
              <th scope="col">Judul</th>
              <th scope="col">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <?php $i = 1; ?>
              <?php foreach ($video as $row) : ?>

                  <th scope="row"><?= $i; ?> </th>
                  <td>
                    <a href="player.php?id=<?= $row["id"]; ?>"><?= $row["judul"]; ?></a>
                  </td>
                  <td>
                      <a href="hapus.php?id=<?= $row["id"];?>" 
                        onclick="return confirm('Yakin?');">Hapus</a>
                  </td>
              </tr>
              <?php $i++; ?>
              <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>
</html>