<?php 
// untuk tes jadi gambar loader bisa muncul agak lama
// sleep(parameter 1 detik)
// sleep(1);

// kalau usleep bisa sampai micro detik
usleep(50000);
    require 'function.php';

    // kita ambil url keyword yang dikirim dari file script.js
    $keyword = $_GET['keyword'];
    
    // function cari kita copykan ke sini
    $query = "SELECT * FROM video
                WHERE
            judul LIKE '%$keyword%'  
            ";
    $video = query($query);

    // untuk tes apakah var mahasiswa sudah berhasil datanya
    // var_dump($mahasiswa);

?>
    <table class="table mt-5">
        <thead class="thead-dark">
        <tr>
            <th scope="col">No.</th>
            <!--Aksi untuk tombol ubah  -->
            <th scope="col">judul</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <?php $i = 1; ?>
            <?php foreach ($video as $row) : ?>

                <th scope="row"><?= $i; ?> </th>
                <td>
                <a href="player.php?id=<?= $row["id"]; ?>"><?= $row["judul"]; ?></a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach ?>
        </tbody>
    </table>