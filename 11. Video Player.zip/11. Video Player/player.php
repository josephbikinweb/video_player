<?php
require 'function.php';

// ambil data di URL
$id = $_GET["id"];

// querydata mahasiswa berdasarkan id
// angka 0 adalah query array indeks luarnya yaitu ke 0 bisa di lihat di web browser dan view page source
$row = query("SELECT * FROM video WHERE id = $id")[0];
$video = query("SELECT * FROM video ORDER BY video");

if (isset($_POST["cari"])) {
    $video = cari($_POST["keyword"]);
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Video Player</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="container my-5">
      <div class="row">
        <form action="" method="post">
          <div class="form-inline">
            <input type="text" name="keyword" size="40" autofocus placeholder="masukkan keyword pencarian.." autocomplete="off"  class="form-control" id="keyword">
            <button type="submit" name="cari" class="btn btn-primary ml-2" id="tombol-cari">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
            </button>
          </div>
        </form>
      </div>
    </div>

    <section>
      <div class="container">
        <div class="row">
          <video class="video" controls>
            <source src="video/<?= $row["video"]; ?>" type="video/mp4">
          </video>
        </div>
      </div>
    </section>

    <div class="container" id="container">
      <div class="row">
        <table class="table mt-5">
          <thead class="thead-dark">
            <tr>
              <th scope="col">No.</th>
              <!--Aksi untuk tombol ubah  -->
              <th scope="col">judul</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <?php $i = 1; ?>
              <?php foreach ($video as $row) : ?>

                  <th scope="row"><?= $i; ?> </th>
                  <td>
                    <a href="player.php?id=<?= $row["id"]; ?>"><?= $row["judul"]; ?></a>
                  </td>
              </tr>
              <?php $i++; ?>
              <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
  </body>
</html>
